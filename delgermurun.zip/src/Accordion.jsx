import React, { useState } from 'react';

function AccordionItem({ title, content }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="accordion-item">
      <div className="accordion-header" onClick={toggleAccordion}>
        <h2>{title}</h2>
        <span className={`icon ${isOpen ? 'open' : 'closed'}`}></span>
      </div>
      {isOpen && <div className="accordion-content">{content}</div>}
    </div>
  );
}

function Accordion() {
  const accordionData = [
    { title: 'What is lorem insput', content: 'lorem lorem lorem is lorem' },
    { title: 'Where does it come from', content: 'I don t know maybe Americian' },
    { title: 'Why do we use it', content: 'Because we are lazy' },
    { title: 'Where can i get some', content: 'Everywhere if you want just type lorem and your number ' },
  ];

  return (
    <div className="accordion">
      {accordionData.map((item, index) => (
        <AccordionItem
          key={index}
          title={item.title}
          content={item.content}
        />
      ))}
    </div>
  );
}

export default Accordion;
