import React, { useState } from 'react';

function Search() {
  const [searchInput, setSearchInput] = useState('');
  const [filteredData, setFilteredData] = useState([]);

  const data = [
    { id: 1, name: 'Apple' },
    { id: 2, name: 'Banana' },
    { id: 3, name: 'Pineapple' },
    { id: 4, name: 'Peer' },
    { id: 5, name: 'Lemon' },
    { id: 6, name: 'Watermelon' },
    { id: 7, name: 'orange' },
    { id: 8, name: 'carrot' },
  ];

  const handleSearchInput = (event) => {
    const inputValue = event.target.value;
    setSearchInput(inputValue);

    const filtered = data.filter(item =>
      item.name.toLowerCase().includes(inputValue.toLowerCase())
    );

    setFilteredData(filtered);
  };

  return (
    <div>
      <h1>Search Filter Example</h1>
      <input
        type="text"
        placeholder="Search..."
        value={searchInput}
        onChange={handleSearchInput}
      />
      <ul>
        {filteredData.map(item => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default Search;
