import React from 'react';
import '../Pages/Login.css'
import FacebookOutlinedIcon from '@mui/icons-material/FacebookOutlined';
import TwitterIcon from '@mui/icons-material/Twitter';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
const LoginPage=()=> {
  return (
    <div className="login-page">
      <div className='grad'>
        <h2>Welcome to login</h2>
        <h5>Don t have acc?</h5>
        <button>Sign up</button>
      </div>
      <h1>Sign In</h1>
      <FacebookOutlinedIcon className='Face'/>
      <TwitterIcon className='Twit'/>
      <CheckBoxIcon className='Check'/>
        
        <div className="Username">
          <label>Username</label>
          <input
          className='1'
          placeholder='Username'
            type="Username"
            required
          />
        </div>
        <div className="Password">
          <label>Password</label>
          <input
          className='2'
          placeholder='Password'
            type="password"
            required
          />
        </div>
        <button class="button-62" role="button" type="submit">Login</button>
        <p className='Rem'>Remember me</p>
        <p className='Forget'>Forget Password</p>
    </div>
  );
}

export default LoginPage;
