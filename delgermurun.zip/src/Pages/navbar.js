import React from "react";
import { Link } from "react-router-dom";

const Navbar=()=> {
  return (
    <header>
      <div className="menu">
        <Link to={"/home"}>Home</Link>
        <Link to={"/login"}>Login</Link>
      </div>
    </header>
  );
}

export default Navbar;