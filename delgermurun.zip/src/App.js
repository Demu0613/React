import './App.css';
// import Search from './Search';
// import Accordion from './Accordion';
// import Image from './Image';
import LoginPage from './Pages/LoginPage';
import { Route,Routes } from 'react-router-dom';
import Home from './Pages/Home';
import Navbar from './Pages/navbar';

function App() {
  return (
  <div>
     {/* <Search/>
     <Accordion/>
     <Image/> */}
      <Navbar/>
      <Routes>
        <Route path='/home' element={<Home/>}/>
        <Route path='/login' element={<LoginPage/>}/>
      </Routes>
  </div>
      
  );
}

export default App;
