import React, { useState } from 'react';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import ArrowCircleLeftIcon from '@mui/icons-material/ArrowCircleLeft';

function ImageSlider({ images }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    setCurrentSlide((currentSlide + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentSlide((currentSlide - 1 + images.length) % images.length);
  };

  return (
    <div className="image-slider">
      <button onClick={prevSlide}><ArrowCircleLeftIcon/></button>
      <img src={images[currentSlide]} alt={`Slide ${currentSlide}`} />
      <button onClick={nextSlide}><ArrowCircleRightIcon/></button>
    </div>
  );
}

function Image() {
  const imageUrls = [
    'https://th.bing.com/th/id/OIP.wKTalIovavvhlcXcGhvvPAHaHI?w=188&h=181&c=7&r=0&o=5&pid=1.7',
    'https://th.bing.com/th/id/OIP.q4Nln1Pt0tvu1XRq5U_M2QAAAA?w=152&h=181&c=7&r=0&o=5&pid=1.7',
    'https://th.bing.com/th/id/OIP.h5xZitH7RshpgkmAsFRaSgHaE8?w=272&h=181&c=7&r=0&o=5&pid=1.7',
  ];

  return (
    <div className="App">
      <h1>Image Slider Example</h1>
      <ImageSlider images={imageUrls} />
    </div>
  );
}

export default Image;
